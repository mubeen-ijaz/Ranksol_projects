-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2023 at 02:11 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adminmirakie_order`
--

-- --------------------------------------------------------

--
-- Table structure for table `coupens`
--

CREATE TABLE `coupens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `type` enum('plain','percentage') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupen_user`
--

CREATE TABLE `coupen_user` (
  `user_id` bigint(20) NOT NULL,
  `coupen_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `social_account` varchar(255) DEFAULT NULL,
  `post_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `email`, `address`, `phone_number`, `social_account`, `post_code`, `created_at`, `updated_at`) VALUES
(8, 'Rana Zaid khan', 'Munawar', 'khan@gmail.com', 'faisalabad', '+923020000214', NULL, '38000', '2023-07-26 00:40:47', '2023-07-26 00:40:47'),
(7, 'Rana Zaid', 'Munawar', 'ranazaidmunawar106@gmail.com', 'fsd', '+923020000214', NULL, '38000', '2023-07-20 07:09:19', '2023-07-20 07:09:19'),
(9, 'mubeen', 'ijaz', 'mubeen.ijaz4337@gmail.com', 'Pakistan ,Punjab,\r\nFaisalabad madina town', '+923093229653', NULL, '1234.', '2023-07-26 18:23:15', '2023-07-26 18:23:15');

-- --------------------------------------------------------

--
-- Table structure for table `data_details`
--

CREATE TABLE `data_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` varchar(255) DEFAULT NULL,
  `links` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_details`
--

INSERT INTO `data_details` (`id`, `role_id`, `links`, `note`, `created_at`, `updated_at`) VALUES
(1, '3', 'https://www.geeksforgeeks.org/laravel-import-export-excel-file/', 'gdfhfghdf', '2023-07-26 05:04:23', '2023-07-26 05:04:23');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(7, '2023_04_04_090242_create_products_table', 3),
(8, '2023_04_06_070017_create_coupens_table', 4),
(9, '2023_04_05_090641_create_permission_tables', 5),
(11, '2023_04_06_092855_create_coupen_user_table', 6),
(12, '2023_04_07_052555_create_orders_table', 7),
(13, '2023_04_07_064831_add_country_field_in_products_table', 8),
(14, '2023_04_07_101948_add_post_code_field_in_customers_table', 9),
(15, '2023_04_04_085606_create_product_variations_table', 10),
(16, '2023_04_14_092947_add_product_field_in_orders_table', 11),
(17, '2023_04_14_093548_create_order_variation_table', 11),
(20, '2023_05_30_050836_create_orderdetails_table', 14),
(21, '2023_06_06_103658_add_new_fields_users', 15),
(22, '2023_04_03_095441_create_customers_table', 16),
(23, '2023_06_07_053635_create_user_status_table', 17),
(24, '2023_07_20_093028_add_new_fields_orders', 18),
(25, '2023_07_20_094510_update_order_table', 19),
(26, '2023_07_20_055424_create_data_details_table', 20),
(27, '2023_07_24_101104_create_payments_invoices_table', 20);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_permissions`
--

INSERT INTO `model_has_permissions` (`permission_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 3),
(1, 'App\\Models\\User', 4),
(1, 'App\\Models\\User', 6),
(1, 'App\\Models\\User', 18),
(2, 'App\\Models\\User', 3),
(2, 'App\\Models\\User', 4),
(2, 'App\\Models\\User', 6),
(2, 'App\\Models\\User', 18),
(3, 'App\\Models\\User', 3),
(3, 'App\\Models\\User', 4),
(3, 'App\\Models\\User', 6),
(3, 'App\\Models\\User', 18),
(4, 'App\\Models\\User', 3),
(4, 'App\\Models\\User', 4),
(4, 'App\\Models\\User', 6),
(4, 'App\\Models\\User', 18),
(5, 'App\\Models\\User', 3),
(5, 'App\\Models\\User', 4),
(5, 'App\\Models\\User', 6),
(5, 'App\\Models\\User', 18),
(6, 'App\\Models\\User', 3),
(6, 'App\\Models\\User', 4),
(6, 'App\\Models\\User', 6),
(6, 'App\\Models\\User', 18),
(7, 'App\\Models\\User', 3),
(7, 'App\\Models\\User', 4),
(7, 'App\\Models\\User', 6),
(7, 'App\\Models\\User', 18),
(8, 'App\\Models\\User', 3),
(8, 'App\\Models\\User', 4),
(8, 'App\\Models\\User', 6),
(8, 'App\\Models\\User', 18),
(9, 'App\\Models\\User', 3),
(9, 'App\\Models\\User', 4),
(9, 'App\\Models\\User', 6),
(9, 'App\\Models\\User', 18),
(10, 'App\\Models\\User', 3),
(10, 'App\\Models\\User', 4),
(10, 'App\\Models\\User', 6),
(10, 'App\\Models\\User', 18),
(11, 'App\\Models\\User', 3),
(11, 'App\\Models\\User', 4),
(11, 'App\\Models\\User', 6),
(11, 'App\\Models\\User', 18),
(12, 'App\\Models\\User', 3),
(12, 'App\\Models\\User', 4),
(12, 'App\\Models\\User', 6),
(12, 'App\\Models\\User', 18),
(13, 'App\\Models\\User', 3),
(13, 'App\\Models\\User', 4),
(13, 'App\\Models\\User', 6),
(13, 'App\\Models\\User', 18),
(14, 'App\\Models\\User', 3),
(14, 'App\\Models\\User', 4),
(14, 'App\\Models\\User', 6),
(14, 'App\\Models\\User', 18),
(15, 'App\\Models\\User', 3),
(15, 'App\\Models\\User', 4),
(15, 'App\\Models\\User', 6),
(15, 'App\\Models\\User', 18),
(16, 'App\\Models\\User', 3),
(16, 'App\\Models\\User', 4),
(16, 'App\\Models\\User', 6),
(16, 'App\\Models\\User', 18),
(17, 'App\\Models\\User', 1),
(17, 'App\\Models\\User', 3),
(17, 'App\\Models\\User', 4),
(17, 'App\\Models\\User', 6),
(17, 'App\\Models\\User', 18),
(18, 'App\\Models\\User', 1),
(18, 'App\\Models\\User', 3),
(18, 'App\\Models\\User', 4),
(18, 'App\\Models\\User', 6),
(18, 'App\\Models\\User', 18),
(19, 'App\\Models\\User', 1),
(19, 'App\\Models\\User', 3),
(19, 'App\\Models\\User', 4),
(19, 'App\\Models\\User', 6),
(19, 'App\\Models\\User', 18),
(20, 'App\\Models\\User', 1),
(20, 'App\\Models\\User', 3),
(20, 'App\\Models\\User', 4),
(20, 'App\\Models\\User', 6),
(20, 'App\\Models\\User', 18),
(21, 'App\\Models\\User', 3),
(21, 'App\\Models\\User', 4),
(21, 'App\\Models\\User', 6),
(21, 'App\\Models\\User', 18),
(22, 'App\\Models\\User', 3),
(22, 'App\\Models\\User', 4),
(22, 'App\\Models\\User', 6),
(22, 'App\\Models\\User', 18),
(23, 'App\\Models\\User', 3),
(23, 'App\\Models\\User', 4),
(23, 'App\\Models\\User', 6),
(23, 'App\\Models\\User', 18),
(24, 'App\\Models\\User', 3),
(24, 'App\\Models\\User', 4),
(24, 'App\\Models\\User', 6),
(24, 'App\\Models\\User', 18),
(25, 'App\\Models\\User', 3),
(25, 'App\\Models\\User', 4),
(25, 'App\\Models\\User', 6),
(25, 'App\\Models\\User', 18),
(26, 'App\\Models\\User', 3),
(26, 'App\\Models\\User', 4),
(26, 'App\\Models\\User', 6),
(26, 'App\\Models\\User', 18),
(27, 'App\\Models\\User', 3),
(27, 'App\\Models\\User', 4),
(27, 'App\\Models\\User', 6),
(27, 'App\\Models\\User', 18),
(28, 'App\\Models\\User', 3),
(28, 'App\\Models\\User', 4),
(28, 'App\\Models\\User', 6),
(28, 'App\\Models\\User', 18),
(29, 'App\\Models\\User', 3),
(29, 'App\\Models\\User', 4),
(29, 'App\\Models\\User', 6),
(29, 'App\\Models\\User', 18);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(2, 'App\\Models\\User', 3),
(3, 'App\\Models\\User', 4),
(3, 'App\\Models\\User', 6),
(3, 'App\\Models\\User', 18),
(4, 'App\\Models\\User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `select_country` varchar(255) NOT NULL,
  `select_product` varchar(255) NOT NULL,
  `mattress_size` varchar(255) DEFAULT NULL,
  `select_mattress` varchar(255) DEFAULT NULL,
  `ottoman_design` varchar(255) DEFAULT NULL,
  `ottoman_color` varchar(255) DEFAULT NULL,
  `ottoman_fabric` varchar(255) DEFAULT NULL,
  `gaslift_size` varchar(255) DEFAULT NULL,
  `gaslift_design` varchar(255) DEFAULT NULL,
  `headboard_size` varchar(255) DEFAULT NULL,
  `headboard_design` varchar(255) DEFAULT NULL,
  `headboard_color` varchar(255) DEFAULT NULL,
  `headboard_fabric` varchar(255) DEFAULT NULL,
  `without_diamond_size` varchar(255) DEFAULT NULL,
  `without_diamond_color` varchar(255) DEFAULT NULL,
  `without_diamond_fabric` varchar(255) DEFAULT NULL,
  `without_diamond_storage` varchar(255) DEFAULT NULL,
  `without_diamond_base` varchar(255) DEFAULT NULL,
  `without_diamond_mattress` varchar(255) DEFAULT NULL,
  `with_diamond_size` varchar(255) DEFAULT NULL,
  `with_diamond_design` varchar(255) DEFAULT NULL,
  `with_diamond_color` varchar(255) DEFAULT NULL,
  `with_diamond_fabric` varchar(255) DEFAULT NULL,
  `with_diamond_button_diamond` varchar(255) DEFAULT NULL,
  `with_diamond_storage` varchar(255) DEFAULT NULL,
  `with_diamond_base` varchar(255) DEFAULT NULL,
  `with_diamond_mattress` varchar(255) DEFAULT NULL,
  `ottoman_divan_size` varchar(255) DEFAULT NULL,
  `ottoman_divan_headboad` varchar(255) DEFAULT NULL,
  `ottoman_divan_color` varchar(255) DEFAULT NULL,
  `ottoman_divan_fabric` varchar(255) DEFAULT NULL,
  `ottoman_divan_mattress` varchar(255) DEFAULT NULL,
  `divan_size` varchar(255) DEFAULT NULL,
  `divan_headboard` varchar(255) DEFAULT NULL,
  `divan_color` varchar(255) DEFAULT NULL,
  `divan_fabric` varchar(255) DEFAULT NULL,
  `divan_storage` varchar(255) DEFAULT NULL,
  `divan_mattress` varchar(255) DEFAULT NULL,
  `monaco_divan_size` varchar(255) DEFAULT NULL,
  `monaco_divan_headboard` varchar(255) DEFAULT NULL,
  `monaco_divan_color` varchar(255) DEFAULT NULL,
  `monaco_divan_fabric` varchar(255) DEFAULT NULL,
  `monaco_divan_storage` varchar(255) DEFAULT NULL,
  `monaco_divan_mattress` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `customer_id`, `user_id`, `order_id`, `select_country`, `select_product`, `mattress_size`, `select_mattress`, `ottoman_design`, `ottoman_color`, `ottoman_fabric`, `gaslift_size`, `gaslift_design`, `headboard_size`, `headboard_design`, `headboard_color`, `headboard_fabric`, `without_diamond_size`, `without_diamond_color`, `without_diamond_fabric`, `without_diamond_storage`, `without_diamond_base`, `without_diamond_mattress`, `with_diamond_size`, `with_diamond_design`, `with_diamond_color`, `with_diamond_fabric`, `with_diamond_button_diamond`, `with_diamond_storage`, `with_diamond_base`, `with_diamond_mattress`, `ottoman_divan_size`, `ottoman_divan_headboad`, `ottoman_divan_color`, `ottoman_divan_fabric`, `ottoman_divan_mattress`, `divan_size`, `divan_headboard`, `divan_color`, `divan_fabric`, `divan_storage`, `divan_mattress`, `monaco_divan_size`, `monaco_divan_headboard`, `monaco_divan_color`, `monaco_divan_fabric`, `monaco_divan_storage`, `monaco_divan_mattress`, `created_at`, `updated_at`) VALUES
(56, 8, 3, '4', '***************899990000', '6', '3ft', 'pillow top 12 inch', 'Monaco-Diamond', 'charcoal', 'Leather', '3ft', 'Metal Gaslift', '6ft inch', 'Floor Standing-Florida Button', 'purple', 'Leather', '5ft', 'silver', 'Plush Velvet', 'Metal Gaslift', 'Wooden Slates', 'Cream 3D 12 inch', '4ft', 'Floor Standing-Florida Button', 'Beige', 'Naples', 'Button', 'Metal Gaslift', 'Wooden Slates', 'Richmond 3D 12 inch', '4ft', 'Florida Diamond', 'Brown', 'Leather', 'Cream 3D 12 inch', '2ft6 inch', 'Hilton Diamond', 'Beige', 'Chenille', '3 Drawers-Side', 'Grey 3D 12 inch', '3ft', NULL, 'blue', 'Leather', '2 Drawers-1 each side Bottom piece', 'Silver 3D 12 inch', '2023-07-26 00:40:47', '2023-07-26 00:40:47'),
(53, 7, 3, '1', 'france', '3', '4ft', 'Memory Gel 12 inch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-07-20 07:09:19', '2023-07-20 07:09:19'),
(54, 7, 3, '2', 'US', '3', '4ft', NULL, NULL, NULL, NULL, NULL, 'select Design', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-07-20 07:12:17', '2023-07-21 05:53:54'),
(55, 7, 3, '3', 'france', '3', '4ft6 inch', 'Cream 3D 12 inch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-07-20 07:13:30', '2023-07-20 07:13:30'),
(57, 9, 3, '5', 'UK', '2', '4ft', 'pillow top 14 inch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-07-26 18:23:15', '2023-07-26 18:23:15');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `note` longtext DEFAULT NULL,
  `price` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `qty` bigint(20) DEFAULT NULL,
  `delivery_status` varchar(255) DEFAULT NULL,
  `delivery_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_number`, `customer_id`, `user_id`, `note`, `price`, `created_at`, `updated_at`, `product_id`, `qty`, `delivery_status`, `delivery_date`) VALUES
(1, 'In-00001-2023', 7, 3, 'testing', '2500', '2023-07-20 07:09:19', '2023-07-20 07:09:19', 3, 25, 'complete', '2023-07-27'),
(2, 'In-00002-2023', 7, 3, 'test', '50', '2023-07-20 07:12:17', '2023-07-21 05:54:15', 3, 5, 'inprocess', '2023-07-10'),
(3, 'In-00003-2023', 7, 3, 'bhfgh', '5454', '2023-07-20 07:13:30', '2023-07-20 07:13:30', 3, 42, 'cancel', '2023-07-17'),
(4, 'In-00004-2023', 8, 3, 'ghfghfcghcgy', '250000', '2023-07-26 00:40:47', '2023-07-26 00:40:47', 4, 25, 'inprocess', '2023-07-27'),
(5, 'In-00005-2023', 9, 3, 'XYZ', '1200', '2023-07-26 18:23:15', '2023-07-26 18:23:15', 2, 2, 'complete', '2023-07-28');

-- --------------------------------------------------------

--
-- Table structure for table `order_variation`
--

CREATE TABLE `order_variation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `design` longtext NOT NULL,
  `size` longtext NOT NULL,
  `headboard` longtext NOT NULL,
  `color_or_fabric` longtext NOT NULL,
  `matteres` longtext NOT NULL,
  `storage` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_variation`
--

INSERT INTO `order_variation` (`id`, `order_id`, `design`, `size`, `headboard`, `color_or_fabric`, `matteres`, `storage`, `created_at`, `updated_at`) VALUES
(1, 20, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(2, 41, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(3, 42, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(4, 43, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(5, 44, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(6, 45, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(7, 46, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(8, 47, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(9, 48, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(10, 49, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(11, 50, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(12, 51, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(13, 52, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(14, 53, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(15, 54, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(16, 55, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(17, 56, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(18, 57, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(19, 58, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(20, 59, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(21, 60, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(22, 61, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(23, 62, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(24, 63, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(25, 64, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(26, 65, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(27, 66, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(28, 67, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(29, 68, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(30, 69, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(31, 70, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(32, 71, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(33, 72, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(34, 73, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(35, 74, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(36, 75, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(37, 76, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(38, 77, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(39, 78, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(40, 79, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(41, 80, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(42, 81, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(43, 82, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(44, 83, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(45, 84, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(46, 85, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(47, 86, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(48, 87, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(49, 88, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(50, 89, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(51, 90, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(52, 91, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(53, 92, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(54, 1, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(55, 2, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(56, 3, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(57, 4, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL),
(58, 5, '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', '[\"default\"]', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments_invoices`
--

CREATE TABLE `payments_invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` varchar(255) DEFAULT NULL,
  `links` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments_invoices`
--

INSERT INTO `payments_invoices` (`id`, `role_id`, `links`, `note`, `created_at`, `updated_at`) VALUES
(1, '3', 'https://www.geeksforgeeks.org/laravel-import-export-excel-file/', 'fghfghfg', '2023-07-26 05:05:06', '2023-07-26 05:05:06');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'View User', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(2, 'Create User', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(3, 'Update User', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(4, 'Delete User', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(5, 'View Role', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(6, 'Create Role', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(7, 'Update Role', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(8, 'Delete Role', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(9, 'View Product', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(10, 'Create Product', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(11, 'Update Product', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(12, 'Delete Product', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(13, 'View Product Variation', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(14, 'Create Product Variation', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(15, 'Update Product Variation', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(16, 'Delete Product Variation', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(17, 'View Order', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(18, 'Create Order', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(19, 'Update Order', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(20, 'Delete Order', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(21, 'View Customer', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(22, 'Create Customer', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(23, 'Update Customer', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(24, 'Delete Customer', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(25, 'View Coupen', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(26, 'Create Coupen', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(27, 'Update Coupen', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(28, 'Delete Coupen', 'web', '2023-04-06 04:58:23', '2023-04-06 04:58:23'),
(29, 'View File Upload', 'web', '2023-05-04 09:43:57', '2023-05-04 09:43:57');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `country` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `created_at`, `updated_at`, `country`) VALUES
(2, 'Bed', '300', '2023-04-23 20:04:38', '2023-04-23 20:04:38', '[\"UK\"]'),
(3, 'Sofas', '100', '2023-05-04 13:35:13', '2023-05-04 13:35:13', '[\"france\"]'),
(4, 'Couch', '100', '2023-05-04 13:35:32', '2023-05-04 13:35:32', '[\"Japan\"]'),
(5, '1112313213ggiig6778895', '......', '2023-05-04 13:36:02', '2023-05-04 13:36:02', '[\"123132156456465456465423165456789731231\"]'),
(6, '%%%^&&**(', '115500 +1 321+ 232565', '2023-05-04 13:36:43', '2023-05-04 13:36:43', '[\"***************899990000\",\" japan\",\" china\",\" france\",\" belgium\",\" argentina\"]');

-- --------------------------------------------------------

--
-- Table structure for table `product_variations`
--

CREATE TABLE `product_variations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `design` longtext DEFAULT NULL,
  `size` longtext DEFAULT NULL,
  `headboard` longtext DEFAULT NULL,
  `color_or_fabric` longtext DEFAULT NULL,
  `matteres` longtext DEFAULT NULL,
  `storage` longtext DEFAULT NULL,
  `product_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_variations`
--

INSERT INTO `product_variations` (`id`, `design`, `size`, `headboard`, `color_or_fabric`, `matteres`, `storage`, `product_id`, `created_at`, `updated_at`) VALUES
(1, '[\"Sleigh\"]', '[\"4ft\"]', '[\"diamond\"]', '[\"blue plush\"]', '[\"simple\"]', '[\"gaslift\"]', 2, '2023-04-28 04:18:08', '2023-04-28 04:18:08');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(2, 'Super Admin', 'web', '2023-04-06 04:58:28', '2023-04-06 05:59:47'),
(3, 'Vendor', 'web', '2023-04-28 04:23:14', '2023-05-04 18:46:54'),
(4, 'Agent', 'web', '2023-05-02 16:49:22', '2023-05-04 18:47:05'),
(5, 'Support', 'web', '2023-06-05 06:39:53', '2023-06-05 06:39:53');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 2),
(1, 3),
(1, 5),
(2, 2),
(2, 3),
(2, 5),
(3, 2),
(3, 3),
(3, 5),
(4, 2),
(4, 3),
(4, 5),
(5, 2),
(5, 3),
(5, 5),
(6, 2),
(6, 3),
(6, 5),
(7, 3),
(7, 5),
(8, 3),
(8, 5),
(9, 3),
(9, 5),
(10, 3),
(10, 5),
(11, 3),
(11, 5),
(12, 3),
(12, 5),
(13, 3),
(13, 5),
(14, 3),
(14, 5),
(15, 3),
(15, 5),
(16, 3),
(16, 5),
(17, 3),
(17, 4),
(17, 5),
(18, 3),
(18, 4),
(18, 5),
(19, 3),
(19, 4),
(19, 5),
(20, 3),
(20, 4),
(20, 5),
(21, 3),
(21, 5),
(22, 3),
(22, 5),
(23, 3),
(23, 5),
(24, 3),
(24, 5),
(25, 3),
(25, 5),
(26, 3),
(26, 5),
(27, 3),
(27, 5),
(28, 3),
(28, 5),
(29, 3),
(29, 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'faraz', 'faraz@gmail.com', NULL, '$2y$10$yDT3RHNz4tV6vspTZQKn4ObrO9r.g5c09dvDIbkKuFEdH0tH0yk6S', NULL, '2023-04-05 04:18:12', '2023-04-05 04:18:12'),
(3, 'Super Admin', 'admin@admin.com', NULL, '$2y$10$VeiDmVkUuuDXZVa7NzKkPOdbLFv09LGEcLZzoXtICo4qnW/ptHK5y', 'gUw2R7uvdQPm7jiJTqLvvroF9WMfyYUhN510uiS20p3Dd823rchlXMasUyfQ', '2023-04-06 04:58:28', '2023-04-06 04:58:28'),
(4, 'Ahmadjunaidali', 'ahmadjunaidali305@gmail.com', NULL, '$2y$10$wmwZOKnyeVr0Gg23ZdCJhOtpQ9baD9VTnakiRmRTVZK1I/RC.dqKS', NULL, '2023-04-28 04:12:17', '2023-04-28 04:33:12'),
(6, 'faizantest', 'faizanali@ranksol.com', NULL, '$2y$10$3AMQM.zTodTOl75QWbAghee2lUnDoyi3wIWbE0KHOPpWV5kBJsn5i', NULL, '2023-05-04 13:14:45', '2023-06-07 01:02:43'),
(18, 'mubeen', 'mubeen@gmail.com', NULL, '$2y$10$1rXOaPiBnmLh1qK6oTCjq.Ei9ACHoSR4Ib4SSidQeD6Cd1Gg.MjxO', NULL, '2023-07-26 17:31:45', '2023-07-26 17:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE `user_status` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`id`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(3, '2', 3, '2023-06-07 05:57:49', '2023-06-06 19:00:00'),
(4, '4', 1, '2023-06-07 05:58:32', '2023-06-07 05:58:32'),
(5, '3', 4, '2023-06-07 06:00:06', '2023-06-07 06:00:06'),
(9, '3', 18, '2023-07-26 17:31:45', '2023-07-26 17:31:45'),
(7, '3', 6, '2023-06-07 06:02:00', '2023-06-07 06:02:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coupens`
--
ALTER TABLE `coupens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupens_name_unique` (`name`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_details`
--
ALTER TABLE `data_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_variation`
--
ALTER TABLE `order_variation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payments_invoices`
--
ALTER TABLE `payments_invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_variations`
--
ALTER TABLE `product_variations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_status`
--
ALTER TABLE `user_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coupens`
--
ALTER TABLE `coupens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `data_details`
--
ALTER TABLE `data_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_variation`
--
ALTER TABLE `order_variation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `payments_invoices`
--
ALTER TABLE `payments_invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product_variations`
--
ALTER TABLE `product_variations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user_status`
--
ALTER TABLE `user_status`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
